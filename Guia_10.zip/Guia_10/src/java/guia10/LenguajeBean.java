/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia10;

/**
 *
 * @author Adriana
 */
public class LenguajeBean {

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the lenguaje
     */
    public String getLenguaje() {
        return lenguaje;
    }

    /**
     * @param lenguaje the lenguaje to set
     */
    public void setLenguaje(String lenguaje) {
        this.lenguaje = lenguaje;
    }
    public String getComentarios()
    {
        if(lenguaje.equals("Java"))
        {
            return "Lenguaje apropiado para portabilidad";
        }
        else if(lenguaje.equals("C++"))
        {
            return "Lenguaje apropiado para desarrollo científico";
        }
        else if(lenguaje.equals("C#"))
        {
            return "Propuesta de Microsoft para POO";
        }
        else if(lenguaje.equals("PHP"))
        {
            return "Lenguaje orientado unicamente a funcionamiento Web";
        }
        else if(lenguaje.equals("Phyton"))
        {
            return "Lenguaje que funciona con Big Data";
        }
        else{
            return "No conozco el lenguaje"+lenguaje;
        }
    }
    private String nombre;
    private String lenguaje;
}
