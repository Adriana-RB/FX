/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia10;

/**
 *
 * @author Adriana
 */
public class ClienteBean {

    /**
     * @return the nom_cli
     */
    public String getNom_cli() {
        return nom_cli;
    }

    /**
     * @param nom_cli the nom_cli to set
     */
    public void setNom_cli(String nom_cli) {
        this.nom_cli = nom_cli;
    }

    /**
     * @return the ape_cli
     */
    public String getApe_cli() {
        return ape_cli;
    }

    /**
     * @param ape_cli the ape_cli to set
     */
    public void setApe_cli(String ape_cli) {
        this.ape_cli = ape_cli;
    }

    /**
     * @return the dir_cli
     */
    public String getDir_cli() {
        return dir_cli;
    }

    /**
     * @param dir_cli the dir_cli to set
     */
    public void setDir_cli(String dir_cli) {
        this.dir_cli = dir_cli;
    }
    private String nom_cli;
    private String ape_cli;
    private String dir_cli;
}
